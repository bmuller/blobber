#ifndef _MISC_UTILS
#define _MISC_UTILS

static float floatAbs(float input){
	
	if(input < 0) return input * -1.0;
	return input;
}

#endif

